create function temps_moyen_traitement_reclamations() returns interval
    language plpgsql
as
$$
BEGIN
    RETURN (
        SELECT AVG(r.date_reclamation - c.date_commande)
        FROM Reclamation r
        JOIN commande c ON r.id_client = c.id_client
        WHERE r.statut = TRUE
    );
END;
$$;

alter function temps_moyen_traitement_reclamations() owner to postgres;

