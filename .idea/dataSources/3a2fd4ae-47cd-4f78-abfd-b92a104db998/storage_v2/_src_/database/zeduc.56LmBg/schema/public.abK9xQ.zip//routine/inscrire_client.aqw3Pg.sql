create function inscrire_client(id_client character varying, nom_client character varying, email_client character varying, secret_client character varying) returns text
    language plpgsql
as
$$
    BEGIN
    -- Inserer les informations dasn la table utilisateur
        INSERT INTO utilisateur(id, nom, email, secret) VALUES (id_client, nom_client, email_client, secret_client);
    --Insere le client dans la table client avec un code généré et 0 points
        INSERT INTO client(id_client, code, points) VALUES (inscrire_client.id_client, generer_code(), 0);

        RETURN 'Client inscrit avec success';
    END ;
$$;

alter function inscrire_client(varchar, varchar, varchar, varchar) owner to postgres;

