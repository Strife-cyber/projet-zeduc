create function reclamations_resolues() returns integer
    language plpgsql
as
$$
BEGIN
    RETURN (
        SELECT COUNT(*)
        FROM Reclamation r
        WHERE r.statut = TRUE
    );
END;
$$;

alter function reclamations_resolues() owner to postgres;

