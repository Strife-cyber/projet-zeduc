create function plats_populaires()
    returns TABLE(nom_plat character varying, total_commande bigint)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY (
        SELECT p.nom, COUNT(c.id_plat) AS total_commande
        FROM plat p
        JOIN commande c ON p.id_plat = c.id_plat
        GROUP BY p.nom
        ORDER BY total_commande DESC
    );
END;
$$;

alter function plats_populaires() owner to postgres;

