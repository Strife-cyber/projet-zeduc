create function revenu_commandes_tous_employes()
    returns TABLE(id_employer character varying, revenu_total bigint)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY (
        SELECT e.id_employer, SUM(p.prix) AS revenu_total
        FROM commande c
        JOIN employer e ON e.id_employer = c.id_client
        JOIN plat p ON c.id_plat = p.id_plat
        GROUP BY e.id_employer
    );
END;
$$;

alter function revenu_commandes_tous_employes() owner to postgres;

