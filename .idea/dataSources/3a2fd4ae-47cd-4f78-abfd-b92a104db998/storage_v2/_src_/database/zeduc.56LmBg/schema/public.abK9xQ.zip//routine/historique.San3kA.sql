create function historique(id character varying)
    returns TABLE(nom character varying, prix integer, status boolean, date date)
    language plpgsql
as
$$
    BEGIN
        RETURN QUERY
        --Sélectionne l'historique des commandes pour l'utilisateur spécifié
        SELECT p.nom, p.prix, c.status, c.date_commande
        FROM commande c JOIN plat p ON c.id_plat = p.id_plat
        WHERE c.id_client = id ORDER BY c.date_commande;
    END ;
$$;

alter function historique(varchar) owner to postgres;

