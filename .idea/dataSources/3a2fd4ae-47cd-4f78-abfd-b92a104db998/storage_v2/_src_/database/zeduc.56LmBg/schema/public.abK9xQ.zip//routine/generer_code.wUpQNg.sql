create function generer_code() returns character varying
    language plpgsql
as
$$
DECLARE
    max_code VARCHAR(5);
    new_code VARCHAR(5);
BEGIN
    -- récupère le code le plus élevé de la table client
    -- Get the maximum code from the client table
    SELECT MAX(code) INTO max_code FROM client;
    -- si la table est vide, retourne '00000'
    -- If the table is empty, return '00000'
    IF max_code IS NULL THEN
        RETURN '00000';
    END IF;

    -- Incrémenter le code au maximum et le remplir de zéros à gauche pour maintenir 5 chiffres
    -- Increment the maximum code and pad it with leading zeros to maintain 5 digits
    new_code := LPAD(CAST(CAST(max_code AS INTEGER) + 1 AS VARCHAR), 5, '0');

    RETURN new_code;
END;
$$;

alter function generer_code() owner to postgres;

