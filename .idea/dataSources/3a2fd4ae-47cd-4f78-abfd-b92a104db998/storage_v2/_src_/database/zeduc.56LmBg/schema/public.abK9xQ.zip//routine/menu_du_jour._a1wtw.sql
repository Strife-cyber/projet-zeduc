create function menu_du_jour(jour date)
    returns TABLE(id_plat character varying, image character varying, nom character varying, prix integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    -- Selectionner les plats disponibles pour le menu du jour
    SELECT p.id_plat, p.image, p.nom, p.prix
    FROM public.menu m -- specify schema if needed
    JOIN public.plat p ON p.id_plat = m.id_plat
    WHERE m.date_menu = jour;
END;
$$;

alter function menu_du_jour(date) owner to postgres;

