create function connexion(email_input character varying, secret_input character varying)
    returns TABLE(id character varying, nom character varying, email character varying, secret character varying, priority integer)
    language plpgsql
as
$$
DECLARE
    utilisateur_row utilisateur%ROWTYPE;
BEGIN
    -- Step 1: Check if the user exists in the utilisateur table
 -- Vérifier si l'utilisateur existe avec l'email et le mot de passe fourn
    SELECT * INTO utilisateur_row
    FROM utilisateur u
    WHERE u.email = email_input AND u.secret = secret_input;

    -- If the user is not found, raise an exception

    -- Si l'utilisateur n'est pas trouvé, lever une exception
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Utilisateur non trouvé ou mauvais identifiants';
    END IF;

    -- Step 2: Check if the user is a gerant (priority 1)
    -- Vérifier si l'utilisateur est un gérant (priorité 1)
    IF EXISTS (SELECT 1 FROM gerant WHERE id_gerant = utilisateur_row.id) THEN
        RETURN QUERY SELECT utilisateur_row.id, utilisateur_row.nom, utilisateur_row.email, utilisateur_row.secret, 1;
        RETURN;
    END IF;

    -- Step 3: Check if the user is an admin (priority 0)
    -- Vérifier si l'utilisateur est un admin (priorité 0)
    IF EXISTS (SELECT 1 FROM admin WHERE id_admin = utilisateur_row.id) THEN
        RETURN QUERY SELECT utilisateur_row.id, utilisateur_row.nom, utilisateur_row.email, utilisateur_row.secret, 0;
        RETURN;
    END IF;

    -- Step 4: Check if the user is an employer (priority 2)
    -- vérifie si l'utilisateur un employer (priorité 2)
    IF EXISTS (SELECT 1 FROM employer WHERE id_employer = utilisateur_row.id) THEN
        RETURN QUERY SELECT utilisateur_row.id, utilisateur_row.nom, utilisateur_row.email, utilisateur_row.secret, 2;
        RETURN;
    END IF;

    -- Step 5: Check if the user is a client (priority 3)
    -- Vérifie si l'utilisateur est un client (priorité 3)
    IF EXISTS (SELECT 1 FROM client WHERE id_client = utilisateur_row.id) THEN
        RETURN QUERY SELECT utilisateur_row.id, utilisateur_row.nom, utilisateur_row.email, utilisateur_row.secret, 3;
        RETURN;
    END IF;

    -- Step 6: If no role is found, raise an exception
    -- Si aucun rôle n'est trouvé pour l'utilisateur, lever une exception
    RAISE EXCEPTION 'Utilisateur trouvé, mais aucun rôle attribué.';
END;
$$;

alter function connexion(varchar, varchar) owner to postgres;

