create function get_top_10_clients()
    returns TABLE(id_client character varying, nom_client character varying, total_commandes bigint)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        c.id_client,
        u.nom AS nom_client,
        COUNT(co.id_commande) AS total_commandes
    FROM
        client c
    JOIN
        utilisateur u ON c.id_client = u.id
    JOIN
        commande co ON c.id_client = co.id_client
    GROUP BY
        c.id_client, u.nom
    ORDER BY
        total_commandes DESC
    LIMIT 10;
END;
$$;

alter function get_top_10_clients() owner to postgres;

