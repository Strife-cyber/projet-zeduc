create function total_commandes_tous_employes()
    returns TABLE(id_employer character varying, total_commandes bigint)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY (
        SELECT e.id_employer, COUNT(l.id_commande) AS total_commandes
        FROM livreur l
        JOIN employer e ON e.id_employer = l.id_employer
        GROUP BY e.id_employer
    );
END;
$$;

alter function total_commandes_tous_employes() owner to postgres;

