create function get_fiole(id_parrain character varying)
    returns TABLE(nom character varying)
    language plpgsql
as
$$
    BEGIN
        RETURN QUERY
        -- Sélectionner les noms des utilisateurs parrainés par le parrin
        SELECT u.nom FROM parrainage p JOIN utilisateur u ON p.fiole = u.id
        WHERE p.parrain = id_parrain;
    END ;
$$;

alter function get_fiole(varchar) owner to postgres;

