create function commande_utilisateur_jour(id_du_client character varying, date date)
    returns TABLE(nom character varying, prix integer, status boolean)
    language plpgsql
as
$$
    BEGIN
        RETURN QUERY
        --Selectionne les plats commandés par l'utilisateur à la date spécifiée
        SELECT p.nom, p.prix, c.status
        FROM commande c JOIN plat p ON c.id_plat = p.id_plat
        WHERE c.id_client = id_du_client AND c.date_commande = date;
    END ;
$$;

alter function commande_utilisateur_jour(varchar, date) owner to postgres;

