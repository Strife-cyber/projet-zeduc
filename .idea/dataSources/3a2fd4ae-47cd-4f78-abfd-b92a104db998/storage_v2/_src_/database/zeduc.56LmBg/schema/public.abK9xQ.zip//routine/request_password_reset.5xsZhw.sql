create function request_password_reset(user_email character varying) returns text
    language plpgsql
as
$$
DECLARE
    users_id VARCHAR;
    reset_token VARCHAR;
BEGIN
-- Verifie si l'email est existe dans la table utilisateur
    -- Step 1: Verify if the email exists in the utilisateur table
    SELECT id INTO users_id FROM utilisateur WHERE email = user_email;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Email not found';
    END IF;

-- générer un token sécurisé
    -- Step 2: Generate a reset token (using a simple random generation example)
    reset_token := encode(gen_random_bytes(32), 'hex'); -- Secure token generation

    -- Enregistrer le token dans la tabe password_reset avec une expiration
    -- Step 3: Store the reset token in a table, along with expiration (e.g., 1 hour)
    INSERT INTO password_resets (user_id, token, expiry)
    VALUES (users_id, reset_token, NOW() + INTERVAL '1 hour');

-- Retourner le token de réinitialisation(en pratique, il serait envoyé par email)
    -- Step 4: Return the reset token (in a real system, you would email this to the user)
    RETURN reset_token;
END;
$$;

alter function request_password_reset(varchar) owner to postgres;

