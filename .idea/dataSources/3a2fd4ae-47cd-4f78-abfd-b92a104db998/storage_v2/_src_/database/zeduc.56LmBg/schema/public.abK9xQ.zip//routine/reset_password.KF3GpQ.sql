create function reset_password(reset_token character varying, new_password character varying) returns text
    language plpgsql
as
$$
DECLARE
    users_id VARCHAR;
BEGIN
-- vérifier si le token est valide et non expiré
    -- Step 1: Find the user based on the reset token and ensure it hasn't expired
    SELECT user_id INTO users_id FROM password_resets
    WHERE token = reset_token AND expiry > NOW();

    IF NOT FOUND THEN
        RAISE NOTICE 'Token: %, Expiry: %', reset_password.reset_token, NOW() ;
    END IF;

    -- Mettre à jour le mot de passe de l'utilisateur
    -- Step 3: Update the user's password in the utilisateur table
    UPDATE utilisateur SET secret = new_password WHERE id = users_id;

-- Supprimer le token après réinitialisation
    -- Step 4: Delete the reset token (one-time use)
    DELETE FROM password_resets WHERE token = reset_token;

    RETURN 'Password reset successfully';
END;
$$;

alter function reset_password(varchar, varchar) owner to postgres;

